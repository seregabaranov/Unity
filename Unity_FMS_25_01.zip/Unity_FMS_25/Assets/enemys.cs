using UnityEngine;

public class enemys : MonoBehaviour
{
    public int count = 10;
    public GameObject enemy;
    public GameObject player;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        for (int i = 0; i < count; i++)
        {
            float x= Random.Range(transform.position.x - transform.localScale.x/2, 
                transform.position.x+ transform.localScale.x / 2), 
                  z = Random.Range(transform.position.z - transform.localScale.z / 2,
                                   transform.position.z + transform.localScale.z / 2);
            GameObject newObject = Instantiate(enemy,
                new Vector3(x, 1, z),
                Quaternion.identity);
            newObject.GetComponent<enemy>().player = player;
        }

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
