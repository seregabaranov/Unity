using UnityEngine;

public class player : MonoBehaviour
{
    Rigidbody rb;
    public float speed = 1.0f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float x = 0, z = 0;
        if (Input.GetKey(KeyCode.D)) x = speed;
        if (Input.GetKey(KeyCode.A)) x = -speed;
        if (Input.GetKey(KeyCode.W)) z = speed;
        if (Input.GetKey(KeyCode.S)) z = -speed;

        rb.AddForce(x, 0, z);
    }
}