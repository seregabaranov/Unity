// player.cs
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;

public class player : MonoBehaviour
{
    Rigidbody rb;
    public float speed = 1.0f;
    public Text text;
    public int HP = 100;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float x = 0, z = 0;
        if (Input.GetKey(KeyCode.D)) x = speed;
        if (Input.GetKey(KeyCode.A)) x = -speed;
        if (Input.GetKey(KeyCode.W)) z = speed;
        if (Input.GetKey(KeyCode.S)) z = -speed;
        rb.AddForce(x, 0, z);
        UpdateHP();
    }

    void UpdateHP()
    {
        if (text)
            text.text = HP.ToString();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<enemy>())
        {
            HP += other.GetComponent<enemy>().deltaHP;
            if (HP < 0) HP = 0;
            if (HP > 100) HP = 100;
            UpdateHP();
            Destroy(other.gameObject);
        }
        if (other.GetComponent<fruit>())
        {
            HP += other.GetComponent<fruit>().deltaHP;
            if (HP < 0) HP = 0;
            if (HP > 100) HP = 100;
            UpdateHP();
            Destroy(other.gameObject);
        }
    }
}