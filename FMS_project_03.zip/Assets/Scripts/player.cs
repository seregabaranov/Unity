using UnityEngine;
using UnityEngine.Networking;
using System;
using System.Collections;

public class player : MonoBehaviour
{
    public float speed = 1;
    private Rigidbody2D rdb;
    public Animator anim;
    public FixedJoystick joistick;

    private bool canJump;
    private Vector2 start;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        canJump = true;
        rdb = GetComponent<Rigidbody2D>();
        start = transform.position;
      //  StartCoroutine(SendRequest());
    }

    // Update is called once per frame
    void Update()
    {
        float x = 0, y = 0;
        if (Input.GetKey(KeyCode.D)) x = speed;
        if (Input.GetKey(KeyCode.A)) x = -speed;
        if (Input.GetKey(KeyCode.W)) y = speed;
        if (Input.GetKey(KeyCode.S)) y = -speed;

        if ((x == 0) && (y == 0))
        {
            x = joistick.Horizontal * speed;
            y = joistick.Vertical * speed;
        }
        //rdb.linearVelocity = new Vector2(x, y);

        //transform.position = new Vector2(transform.position.x + x,
        //                               transform.position.y + y);
        if (x < 0) Left();
        if (x > 0) Right();

        if (rdb.linearVelocity.y == 0)
            canJump = true;

        if (!canJump)
            y = 0;

        if (y > 0)
        {
            rdb.linearVelocity = new Vector2(rdb.linearVelocity.x, y);
            canJump = false;
        }

        if (x != 0)
            anim.Play("walk");
        else
            anim.Play("wait");
        //if (x > 0) Flip(1);
        //if (x < 0) Flip(-1);

    }
    void Flip(int x)
    {
        Vector3 currentScale = gameObject.transform.localScale;
        currentScale.x = Math.Abs(currentScale.x) * x;
        gameObject.transform.localScale = currentScale;

        //facingRight = !facingRight;
    }
    public void Left()
    {
        anim.Play("walk");
        rdb.linearVelocity = new Vector2(-speed, rdb.linearVelocity.y);
        Flip(-1);
    }
    public void Right()
    {
        anim.Play("walk");
        rdb.linearVelocity = new Vector2(speed, rdb.linearVelocity.y);
        Flip(1);
    }
    public void Stop()
    {
        anim.Play("wait");
        rdb.linearVelocity = new Vector2(0, 0);
    }
    public void Jump()
    {
        anim.Play("walk");
        rdb.linearVelocity = new Vector2(rdb.linearVelocity.x, speed);
    }

    void reStart()
    {
        transform.position = start;
        rdb.linearVelocity = new Vector2(0, 0);
    }

    void OnTriggerEnter2D(Collider2D obj)
    {
        //Debug.Log(obj.gameObject.name);
        reStart();
    }

    IEnumerator SendRequest()
    {
        // URL вашего сервера
        //string url = "http://mysql-104929.srv.hoster.ru/serv";
        string url = "barbase.ru/serv/index.php";
        // Создание объекта JSON
        string jsonData = JsonUtility.ToJson(new { name = "значение1", method = "значение2" });
        Debug.Log("SendRequest ");
        // Создание нового POST-запроса
        using (UnityWebRequest www = UnityWebRequest.PostWwwForm(url, jsonData))
        {
            www.SetRequestHeader("Content-Type", "application/json");
            // Добавление параметров
            // www.AddField("param1", "значение1");
            // www.AddField("param2", "значение2");

            // Отправка запроса и ожидание результата
            yield return www.SendWebRequest();

            // Проверка на наличие ошибок
            if (www.result == UnityWebRequest.Result.ConnectionError || www.result == UnityWebRequest.Result.ProtocolError)
            {
                Debug.Log(www.error); // Логирование ошибки
            }
            else
            {
                Debug.Log("Ответ: " + www.downloadHandler.text); // Вывод полученного ответа
            }
        }
    }
}
