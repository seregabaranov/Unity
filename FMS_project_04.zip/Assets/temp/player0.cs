using UnityEngine;
using System;
public class player0 : MonoBehaviour
{
    public float speed = 1;
    private Rigidbody2D rdb;
    public Animator anim;
    public FixedJoystick joistick;
    private bool canJump;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rdb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {

        float x = 0, y = 0;
        if (Input.GetKey(KeyCode.D)) x = speed;
        if (Input.GetKey(KeyCode.A)) x = -speed;
        if (Input.GetKey(KeyCode.W)) y = speed;
        if (Input.GetKey(KeyCode.S)) y = -speed;


        float x_j = joistick.Horizontal * speed;
        float y_j = joistick.Vertical * speed;

        if (x_j != 0) x = x_j;
        if (y_j != 0) y = y_j;

        rdb.linearVelocity = new Vector2(x, y);

        Vector3 currentScale = gameObject.transform.localScale;
        currentScale.x = Math.Abs(currentScale.x) * ((x >= 0)?1 : -1);
        gameObject.transform.localScale = currentScale;

        if (x != 0)
            anim.Play("walk");
        else
            anim.Play("wait");

    }
}
