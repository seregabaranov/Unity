using UnityEngine;
using UnityEngine.SceneManagement;

public class interface_script : MonoBehaviour
{

 public void menuButton()
    {
        SceneManager.LoadScene("scene_start");
    }
}
