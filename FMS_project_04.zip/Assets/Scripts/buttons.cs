using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class buttons : MonoBehaviour
{
    public InputField field;

    public void StartGame()
    {
        
        PlayerPrefs.SetString("Name", field.text);
        SceneManager.LoadScene("SampleScene");
    }

    public void StartScreen()
    {
        SceneManager.LoadScene("startscreen");
    }

    public void Exit()
    {
        Application.Quit();
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        if (PlayerPrefs.GetString("Name")!="")
            if (field)
              field.text = PlayerPrefs.GetString("Name");
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
