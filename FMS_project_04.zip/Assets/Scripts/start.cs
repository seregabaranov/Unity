using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class start : MonoBehaviour
{
    public InputField field; 
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        string name = PlayerPrefs.GetString("Name");
        if (name!="")
        {
            field.text = name;
        }

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SaveName()
    {
        string name = field.text;
        PlayerPrefs.SetString("Name", name);
        SceneManager.LoadScene("SampleScene");
    }

    public void Exit()
    {
        Application.Quit();
    }
}
