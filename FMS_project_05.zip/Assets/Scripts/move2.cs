using UnityEngine;

public class move2 : MonoBehaviour
{
    public float speed = 1;
    public Animator anim;
    public FixedJoystick joistick;

    private Vector2 start;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        start = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        Rigidbody2D rdb = GetComponent<Rigidbody2D>();
        float x = 0;
        float y = 0;

        if (Input.GetKey(KeyCode.D)) x = speed;
        if (Input.GetKey(KeyCode.A)) x = -speed;
        if (Input.GetKey(KeyCode.W)) y = speed;

        if ((x == 0) && (y == 0))
        {
            x = joistick.Horizontal * speed;
            y = joistick.Vertical * speed;
        }

        if (x==0)
            anim.Play("idle");
        else
            anim.Play("run");


        rdb.linearVelocity = new Vector2(x, y);
    }

    void OnTriggerEnter2D(Collider2D obj)
    {
        //Debug.Log(obj.gameObject.name);
        if (obj.gameObject.name == "hole")
            transform.position = start;
    }
}
