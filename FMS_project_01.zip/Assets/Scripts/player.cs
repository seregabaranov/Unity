using UnityEngine;
using System;
public class player : MonoBehaviour
{
    public float speed = 1;
    private Rigidbody2D rdb;
    public Animator anim;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rdb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        float x = 0, y = 0;
        if (Input.GetKey(KeyCode.D)) x = speed;
        if (Input.GetKey(KeyCode.A)) x = -speed;
        if (Input.GetKey(KeyCode.W)) y = speed;
        if (Input.GetKey(KeyCode.S)) y = -speed;

        //transform.position = new Vector2(transform.position.x + x,
        //                               transform.position.y + y);
        if (x < 0) Left();
        if (x > 0) Right();

       
        if (y>0)
            rdb.linearVelocity = new Vector2(rdb.linearVelocity.x, y);
        if (x != 0)
            anim.Play("walk");
        else
            anim.Play("wait");
        //if (x > 0) Flip(1);
        //if (x < 0) Flip(-1);
    }
    void Flip(int x)
    {
        Vector3 currentScale = gameObject.transform.localScale;
        currentScale.x = Math.Abs(currentScale.x)*x;
        gameObject.transform.localScale = currentScale;

       //facingRight = !facingRight;
    }
    public void Left()
    {
        anim.Play("walk");
        rdb.linearVelocity = new Vector2(-speed, rdb.linearVelocity.y);
        Flip(-1);
    }
    public void Right()
    {
        anim.Play("walk");
        rdb.linearVelocity = new Vector2(speed, rdb.linearVelocity.y);
        Flip(1);
    }
    public void Stop()
    {
        anim.Play("wait");
        rdb.linearVelocity = new Vector2(0, 0);
    }
    public void Jump()
    {
        anim.Play("walk");
        rdb.linearVelocity = new Vector2(rdb.linearVelocity.x, speed);
    }
}
