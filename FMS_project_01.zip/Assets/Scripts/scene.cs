using UnityEngine;

public class scene : MonoBehaviour
{
    public float x0;
    public float y0;
    public float scale;
    public GameObject clone;
    public GameObject cloneWall;
    public GameObject cloneApple;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        GameObject[] mas = { null, clone , cloneWall, cloneApple};
        int[,] pos = { { 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 2, },
                       { 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 2, },
                       { 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, },
                       { 2, 0, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, },
                       { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, },
                        };

        for (int i = 0; i < 11; i++)
        {
            int x = Random.Range(1, pos.GetLength(1) - 2);
            int y = Random.Range(0, pos.GetLength(0) - 2);
            pos[y, x] = 2;
        }


        for (int i = 0; i < pos.GetLength(0); i++)
            for (int j = 0; j < pos.GetLength(1); j++)
                if (pos[i, j] > 0)
                {
                        var child = Instantiate(mas[pos[i, j]], new Vector2((j + x0) * scale,
                            (pos.GetLength(0) - i + y0) * scale), Quaternion.identity);
                        child.transform.SetParent(this.transform);
                       
                };

    }


// Update is called once per frame
void Update()
{

}
}

